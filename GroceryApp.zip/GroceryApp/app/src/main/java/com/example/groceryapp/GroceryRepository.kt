package com.example.groceryapp

class GroceryRepository(private val db: GroceryDatabase) {

    suspend fun insert(items: Items) = db.getGroceryDao().insert(items)

    suspend fun delete(items: Items) = db.getGroceryDao().delete(items)

    suspend fun update(qtn : Int, price : Double, name : String) = db.getGroceryDao().update(qtn, price, name)

    fun getAllItems() = db.getGroceryDao().getAllGroceryItems()
}