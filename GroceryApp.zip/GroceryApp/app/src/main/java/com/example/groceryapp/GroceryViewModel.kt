package com.example.groceryapp

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class GroceryViewModel(private val repository: GroceryRepository) : ViewModel() {

    fun insert(items: Items) = GlobalScope.launch {
        repository.insert(items)
    }

    fun delete(items: Items) = GlobalScope.launch {
        repository.delete(items)
    }

    fun update(qtn : Int, price : Double, name : String ) = GlobalScope.launch {
        repository.update(qtn, price, name)
    }

    fun getAllGroceryItems() = repository.getAllItems()

}