package com.example.groceryapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class GroceryAdapter(var list: List<Items>, val groceryClickInterface: GroceryItemClickInterface): RecyclerView.Adapter<GroceryAdapter.GroceryViewHolder>() {

    inner class GroceryViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        val nameText = itemView.findViewById<TextView>(R.id.nameItem)
        val quantityText = itemView.findViewById<TextView>(R.id.quantityItem)
        val priceText = itemView.findViewById<TextView>(R.id.priceItem)
        val totalText = itemView.findViewById<TextView>(R.id.valueCost)
        val deleteBtn = itemView.findViewById<ImageButton>(R.id.delete_img)
        val editBtn = itemView.findViewById<ImageButton>(R.id.edit_img)
    }

    interface GroceryItemClickInterface{

        fun onItemClick(items: Items)
        fun updateItemClick(updatedItems: Items)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): GroceryViewHolder {

        val view = LayoutInflater.from(parent.context).inflate(R.layout.grocery_list, parent, false)
        return GroceryViewHolder(view)
    }

    override fun onBindViewHolder(holder: GroceryViewHolder, position: Int) {

        holder.nameText.text = list.get(position).name
        holder.quantityText.text = list.get(position).quantity.toString()
        holder.priceText.text = "₹ "+ list.get(position).price.toString()

        val itemTotal: Double = list.get(position).price * list.get(position).quantity
        holder.totalText.text = "₹ "+ itemTotal.toString()

        holder.deleteBtn.setOnClickListener{
            groceryClickInterface.onItemClick(list.get(position))
        }

        holder.editBtn.setOnClickListener {
            groceryClickInterface.updateItemClick(list.get(position))
        }
    }

    override fun getItemCount(): Int {
        return list.size
    }
}