package com.example.groceryapp

import android.app.Dialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity(), GroceryAdapter.GroceryItemClickInterface {

    lateinit var items: RecyclerView
    lateinit var addBtn: FloatingActionButton
    lateinit var list: List<Items>
    lateinit var groceryAdapter: GroceryAdapter
    lateinit var groceryViewModel: GroceryViewModel

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        items = findViewById(R.id.homePage)
        addBtn = findViewById(R.id.add_button)
        list = ArrayList<Items>()
        groceryAdapter = GroceryAdapter(list, this)
        items.layoutManager = LinearLayoutManager(this)
        items.adapter = groceryAdapter
        val groceryRepository = GroceryRepository(GroceryDatabase(this))
        val factory = GroceryViewModelFactory(groceryRepository)
        groceryViewModel = ViewModelProvider(this, factory).get(GroceryViewModel::class.java)
        groceryViewModel.getAllGroceryItems().observe(this, Observer {
            groceryAdapter.list = it
            groceryAdapter.notifyDataSetChanged()
        })

        addBtn.setOnClickListener {
            openDialog()
        }
    }

    fun openDialog() {

        val dialog = Dialog(this)
        dialog.setContentView(R.layout.grocery_dialog)
        val nameEdit = dialog.findViewById<EditText>(R.id.edit_name)
        val priceEdit = dialog.findViewById<EditText>(R.id.edit_price)
        val quantityEdit = dialog.findViewById<EditText>(R.id.edit_quantity)
        val cancelBtn = dialog.findViewById<Button>(R.id.btn_cancel)
        val addBtn = dialog.findViewById<Button>(R.id.btn_add)

        cancelBtn.setOnClickListener {
            dialog.dismiss()
        }

        addBtn.setOnClickListener {
            val name : String = nameEdit.text.toString()
            val quantity : String = quantityEdit.text.toString()
            val price : String = priceEdit.text.toString()
            val qtn : Int = quantity.toInt()
            val cost : Double = price.toDouble()

            if (name.isNotEmpty() && quantity.isNotEmpty() && price.isNotEmpty()) {

                val items = Items(name, qtn, cost)
                groceryViewModel.insert(items)
                Toast.makeText(applicationContext, "Item is Inserted Successfully", Toast.LENGTH_SHORT).show()
                groceryAdapter.notifyDataSetChanged()
                dialog.dismiss()
            }
            else {
                Toast.makeText(applicationContext, "Please Enter all the field", Toast.LENGTH_SHORT).show()

            }

        }
        dialog.show()
    }

    override fun onItemClick(items: Items) {

        groceryViewModel.delete(items)
        groceryAdapter.notifyDataSetChanged()
        Toast.makeText(applicationContext, "Item is Deleted Successfully", Toast.LENGTH_SHORT).show()
    }

    override fun updateItemClick(updatedItems: Items) {

        val updateDialog = Dialog(this)
        updateDialog.setContentView(R.layout.grocery_update)
        val nameUpdate = updateDialog.findViewById<EditText>(R.id.update_name)
        val quantityUpdate = updateDialog.findViewById<EditText>(R.id.update_quantity)
        val priceUpdate = updateDialog.findViewById<EditText>(R.id.update_price)
        val cancelBtn = updateDialog.findViewById<Button>(R.id.btn_cancel)
        val confirmBtn = updateDialog.findViewById<Button>(R.id.btn_update)

        cancelBtn.setOnClickListener {
            updateDialog.dismiss()
        }

        confirmBtn.setOnClickListener {
            val updatedName : String = nameUpdate.text.toString()
            val updatedQuantity : String = quantityUpdate.text.toString()
            val updatedPrice : String = priceUpdate.text.toString()
            val updatedQtn : Int = updatedQuantity.toInt()
            val updatedCost : Double = updatedPrice.toDouble()

            if (updatedName.isNotEmpty() && updatedQuantity.isNotEmpty() && updatedPrice.isNotEmpty()) {

                groceryViewModel.update(updatedQtn, updatedCost, updatedName)
                Toast.makeText(applicationContext, "Item is Updated Successfully", Toast.LENGTH_SHORT).show()
                groceryAdapter.notifyDataSetChanged()
                updateDialog.dismiss()
            }
            else {
                Toast.makeText(applicationContext, "Please Enter all the field", Toast.LENGTH_SHORT).show()

            }

        }
        updateDialog.show()
    }
}



















