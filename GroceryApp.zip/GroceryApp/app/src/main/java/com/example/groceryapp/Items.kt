package com.example.groceryapp

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "grocery_list")
data class Items(

    @ColumnInfo(name = "itemName")
    var name: String,

    @ColumnInfo(name = "itemQuantity")
    var quantity: Int,

    @ColumnInfo(name = "itemPrice")
    var price: Double,

    ) {

    @PrimaryKey(autoGenerate = true)
    var id: Int? = null
}