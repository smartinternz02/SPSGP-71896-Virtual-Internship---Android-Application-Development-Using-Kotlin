package com.example.groceryapp

import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface GroceryDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: Items)

    @Delete
    suspend fun delete(item: Items)

    @Query("Update grocery_list set itemQuantity =:qtn, itemPrice =:price where itemName =:name")
    suspend fun update(qtn : Int, price : Double, name : String)

    @Query("SELECT * FROM grocery_list order by itemName")
    fun getAllGroceryItems(): LiveData<List<Items>>
}